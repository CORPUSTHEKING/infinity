def register(bus, router, registry, ctx):

    registry.register_plugin(
        "example",
        ["search"]
    )

    def on_query(payload):

        candidates = [
            {
                "key": "sed",
                "type": "command",
                "title": "sed",
                "short": "Stream editor"
            },
            {
                "key": "awk",
                "type": "command",
                "title": "awk",
                "short": "Pattern processing language"
            }
        ]

        bus.emit("event.candidates", {
            "candidates": candidates
        })

    bus.subscribe("event.query", on_query)
