#!/usr/bin/env python3

from core.transport_bus import TransportBus
from core.plugin_loader import PluginLoader
from core.capability_registry import CapabilityRegistry
from core.context_manager import ContextManager
from core.imf_router import IMFRouter
import core.preview as preview

def main():

    print("Infinity Runtime")
    print("Type 'exit' to quit\n")

    bus = TransportBus()
    registry = CapabilityRegistry()
    ctx = ContextManager()

    router = IMFRouter(bus, preview, registry, ctx)

    loader = PluginLoader("runtime/plugins")
    loader.load_all(bus, router, registry, ctx)

    context = ctx.create()

    while True:

        q = input("∞ > ").strip()

        if q in ("exit","quit"):
            break

        router.query(q, context)

if __name__ == "__main__":
    main()
