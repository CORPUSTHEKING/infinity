import uuid

class ContextManager:

    def __init__(self):
        self.contexts = {}

    def create(self):
        cid = str(uuid.uuid4())
        self.contexts[cid] = {}
        return cid
