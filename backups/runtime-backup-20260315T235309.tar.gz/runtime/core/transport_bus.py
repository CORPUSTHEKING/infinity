#!/usr/bin/env python3
"""Simple in-process event bus."""

from typing import Callable, Dict, List, Any

EventHandler = Callable[[Dict[str, Any]], None]

class TransportBus:

    def __init__(self):
        self._subscribers: Dict[str, List[EventHandler]] = {}

    def subscribe(self, event: str, handler: EventHandler):
        self._subscribers.setdefault(event, []).append(handler)

    def emit(self, event: str, payload: Dict[str, Any]):
        for h in self._subscribers.get(event, []):
            h(payload)
