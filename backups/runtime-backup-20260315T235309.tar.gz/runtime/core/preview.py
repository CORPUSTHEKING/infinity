def render(payload):

    print("\n=== Infinity Preview ===")

    for item in payload.get("items", []):
        print(f"\n> {item.get('title')}")
        print(item.get("body"))
