import os
import importlib.util

class PluginLoader:

    def __init__(self, plugin_dir):
        self.plugin_dir = plugin_dir

    def load_all(self, bus, router, registry, ctx):

        for f in os.listdir(self.plugin_dir):

            if not f.endswith(".py"):
                continue

            path = os.path.join(self.plugin_dir, f)

            spec = importlib.util.spec_from_file_location(f, path)
            mod = importlib.util.module_from_spec(spec)

            spec.loader.exec_module(mod)

            if hasattr(mod, "register"):
                mod.register(bus, router, registry, ctx)
