class CapabilityRegistry:

    def __init__(self):
        self.plugins = {}

    def register_plugin(self, plugin_id, capabilities, meta=None):
        self.plugins[plugin_id] = {
            "capabilities": capabilities,
            "meta": meta or {}
        }

    def list_plugins(self):
        return self.plugins
