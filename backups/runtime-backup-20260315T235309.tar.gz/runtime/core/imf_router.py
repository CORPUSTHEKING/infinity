from concurrent.futures import ThreadPoolExecutor
import core.preview as preview

class IMFRouter:

    def __init__(self, bus, preview_renderer, registry, ctx):
        self.bus = bus
        self.preview = preview_renderer
        self.registry = registry
        self.ctx = ctx

        self.executor = ThreadPoolExecutor(max_workers=8)

        bus.subscribe("event.candidates", self._handle_candidates)

        self.adapters = []

    def register_adapter(self, func):
        self.adapters.append(func)

    def query(self, q, context):

        futures = []

        for adapter in self.adapters:
            futures.append(self.executor.submit(adapter, q))

        candidates = []

        for f in futures:
            try:
                r = f.result(timeout=2)
                if r:
                    candidates.extend(r)
            except Exception:
                pass

        if not candidates:
            return

        preview_payload = {
            "items": [
                {
                    "title": c.get("title"),
                    "body": c.get("short")
                }
                for c in candidates
            ]
        }

        preview.render(preview_payload)

    def _handle_candidates(self, payload):
        pass
