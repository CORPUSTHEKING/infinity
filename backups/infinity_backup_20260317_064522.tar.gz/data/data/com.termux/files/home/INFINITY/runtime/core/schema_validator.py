#!/usr/bin/env python3
"""Simple JSON Schema loader & validator for IMF v1.

Loads schemas from runtime/imf/schemas and validates envelopes + payloads.
"""
from __future__ import annotations
import json
import os
from typing import Dict, Any, Optional
from jsonschema import Draft7Validator, ValidationError

SCHEMA_DIR = os.path.join(os.path.dirname(__file__), "..", "imf", "schemas")

def _load(schema_file: str) -> Dict[str, Any]:
    path = os.path.join(SCHEMA_DIR, schema_file)
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)

# Load canonical schemas
ENVELOPE_SCHEMA = _load("envelope.v1.json")
QUERY_SCHEMA = _load("query.v1.json")
CANDIDATES_SCHEMA = _load("candidates.v1.json")
PREVIEW_SCHEMA = _load("preview.v1.json")

TYPE_TO_SCHEMA = {
    "query": QUERY_SCHEMA,
    "candidates": CANDIDATES_SCHEMA,
    "preview": PREVIEW_SCHEMA,
}

def validate_envelope(envelope: Dict[str, Any]) -> Optional[str]:
    """Validate top-level envelope and payload (if known).
    Returns None on success, or an error string on failure.
    """
    try:
        Draft7Validator(ENVELOPE_SCHEMA).validate(envelope)
    except ValidationError as e:
        return f"envelope.validation_error: {e.message}"

    mtype = envelope.get("type")
    payload = envelope.get("payload", {})
    schema = TYPE_TO_SCHEMA.get(mtype)
    if schema:
        try:
            Draft7Validator(schema).validate(payload)
        except ValidationError as e:
            return f"payload.validation_error ({mtype}): {e.message}"

    return None
