#!/usr/bin/env python3
"""Dynamic plugin loader."""
from __future__ import annotations
import importlib.util
import logging
import os
from typing import Optional

_log = logging.getLogger("infinity.plugin_loader")

class PluginLoader:
    def __init__(self, plugin_dir: str, logger: logging.Logger | None = None) -> None:
        self.plugin_dir = plugin_dir
        self._logger = logger or _log
        self._loaded: dict[str, str] = {}

    def discover_plugins(self) -> list[str]:
        if not os.path.isdir(self.plugin_dir):
            return []
        return [f for f in os.listdir(self.plugin_dir) if f.endswith(".py") and not f.startswith("_")]

    def load_all(self, bus, router, registry, context_mgr) -> None:
        for fname in self.discover_plugins():
            path = os.path.join(self.plugin_dir, fname)
            plugin_id = os.path.splitext(fname)[0]
            try:
                spec = importlib.util.spec_from_file_location(plugin_id, path)
                mod = importlib.util.module_from_spec(spec)
                loader = spec.loader
                assert loader is not None
                loader.exec_module(mod)
                if hasattr(mod, "register") and callable(mod.register):
                    mod.register(bus=bus, router=router, registry=registry, context_mgr=context_mgr, logger=logging.getLogger(f"plugin.{plugin_id}"))
                    self._loaded[plugin_id] = path
                    self._logger.info("plugin_loaded", extra={"plugin_id": plugin_id, "path": path})
                else:
                    self._logger.warning("plugin_missing_register", extra={"plugin_id": plugin_id, "path": path})
            except Exception:
                self._logger.exception("plugin_load_failed", extra={"plugin": fname})

    def list_loaded(self) -> dict:
        return dict(self._loaded)
