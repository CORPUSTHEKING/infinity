#!/usr/bin/env python3
"""IMF router: basic envelope validation and routing.

- validate basic envelope keys
- route 'query' envelopes to 'event.query'
- listen for 'event.candidates' (from plugins) and forward to preview.render via 'event.preview'
- handle preview_request envelopes (type == 'preview_request') to 'event.preview_request'
"""
from __future__ import annotations
import logging
import time
import uuid
from typing import Dict, Any

_log = logging.getLogger("infinity.imf_router")

REQUIRED_ENVELOPE_KEYS = {"imf_version", "type", "id", "origin", "timestamp", "payload"}

class IMFRouter:
    def __init__(self, bus, preview_renderer, registry, context_mgr, logger: logging.Logger | None = None) -> None:
        self.bus = bus
        self.preview = preview_renderer
        self.registry = registry
        self.context_mgr = context_mgr
        self._logger = logger or _log

        # subscribe to plugin candidate events so router can forward to preview surface
        self.bus.subscribe("event.candidates", self._on_candidates)

    def validate_envelope(self, env: Dict[str, Any]) -> bool:
        missing = [k for k in REQUIRED_ENVELOPE_KEYS if k not in env]
        if missing:
            self._logger.error("envelope_missing_keys", extra={"missing": missing, "id": env.get("id")})
            return False
        return True

    def handle_envelope(self, env: Dict[str, Any]) -> None:
        """Entry point: accept an envelope dict."""
        # light validation
        if not isinstance(env, dict):
            self._logger.error("invalid_envelope_type", extra={"type": type(env)})
            return
        if not REQUIRED_ENVELOPE_KEYS.issubset(env.keys()):
            self._logger.error("envelope_validation_failed", extra={"present_keys": list(env.keys())})
            return

        mtype = env.get("type")
        ctx = env.get("context_id") or self.context_mgr.create()
        # route known types
        if mtype == "query":
            q_payload = {
                "id": env.get("id"),
                "origin": env.get("origin"),
                "context_id": ctx,
                "timestamp": env.get("timestamp"),
                "query": env["payload"].get("query"),
                "mode": env["payload"].get("mode", "interactive")
            }
            self.bus.emit("event.query", q_payload)
            self._logger.info("routed_query", extra={"query": q_payload.get("query"), "context_id": ctx})
        elif mtype == "preview_request":
            token = env["payload"].get("preview_token")
            if token:
                self.bus.emit("event.preview_request", {"preview_token": token, "context_id": ctx})
        else:
            self.bus.emit(f"event.{mtype}", env)
            self._logger.debug("routed_generic", extra={"type": mtype})

    def _on_candidates(self, candidate_envelope: Dict[str, Any]) -> None:
        try:
            preview_payload = {
                "preview_token": f"preview:{str(uuid.uuid4())}",
                "items": [ {"title": c.get("title"), "body": c.get("short"), "examples": c.get("meta", {}).get("examples", []) } for c in candidate_envelope.get("candidates", []) ],
                "meta": {"origin": candidate_envelope.get("origin")}
            }
            self.bus.emit("event.preview", {"preview_payload": preview_payload, "context_id": candidate_envelope.get("context_id")})
            self.preview.render(preview_payload)
        except Exception:
            self._logger.exception("failed_handle_candidates")
